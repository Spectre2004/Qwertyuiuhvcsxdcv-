--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.20
-- Dumped by pg_dump version 9.6.20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Department" (
    "IdDep" integer NOT NULL,
    "Name" character varying(50)
);


ALTER TABLE public."Department" OWNER TO postgres;

--
-- Name: Employeer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employeer" (
    "IdEmployeer" integer NOT NULL,
    "Name" character varying(20),
    "Surname" character varying(20),
    "Patronymic" character varying(20),
    "IdDep" integer,
    "Код сотрудника" integer,
    "фам" character varying(50),
    "имя" character varying(50),
    "отчество" character varying(50),
    id character varying(50)
);


ALTER TABLE public."Employeer" OWNER TO postgres;

--
-- Name: GroupApplication; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupApplication" (
    "IdGroupApp" integer NOT NULL,
    "DateFrom" date,
    "DateTo" date,
    "IdStatus" integer,
    "IdEmployeer" integer
);


ALTER TABLE public."GroupApplication" OWNER TO postgres;

--
-- Name: GroupApplicationVisitor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupApplicationVisitor" (
    "IdGroupAppVisitor" integer NOT NULL,
    "IdGroupApp" integer,
    "IdVisitor" integer
);


ALTER TABLE public."GroupApplicationVisitor" OWNER TO postgres;

--
-- Name: PersonalApplication; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PersonalApplication" (
    "IdPersApp" integer NOT NULL,
    "DateFrom" date,
    "DateTo" date,
    "IdVisitor" integer,
    "IdStatus" integer,
    "IdEmployeer" integer
);


ALTER TABLE public."PersonalApplication" OWNER TO postgres;

--
-- Name: RequireDocument; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RequireDocument" (
    "IdDoc" integer NOT NULL,
    "DocLink" character varying(100) NOT NULL
);


ALTER TABLE public."RequireDocument" OWNER TO postgres;

--
-- Name: Status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Status" (
    "IdStatus" integer NOT NULL,
    "StatusName" character varying(20)
);


ALTER TABLE public."Status" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    "IdUser" integer NOT NULL,
    "Email" character varying(50) NOT NULL,
    "Password" character varying(50) NOT NULL,
    "Login" character varying(50) NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: Visitor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Visitor" (
    "IdVisitor" integer NOT NULL,
    "Name" character varying(20),
    "Surname" character varying(30),
    "Patronymic" character varying(30) NOT NULL,
    "Phone" character varying(18),
    "Organization" character varying(30) NOT NULL,
    description text,
    "DateOfBirth" date NOT NULL,
    "PassportSerial" character(4),
    "PassportNumber" character(6),
    iddoc integer,
    "IdUser" integer,
    "ImagePath" character varying(100)
);


ALTER TABLE public."Visitor" OWNER TO postgres;

--
-- Data for Name: Department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Department" ("IdDep", "Name") FROM stdin;
\.


--
-- Data for Name: Employeer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employeer" ("IdEmployeer", "Name", "Surname", "Patronymic", "IdDep", "Код сотрудника", "фам", "имя", "отчество", id) FROM stdin;
\.


--
-- Data for Name: GroupApplication; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupApplication" ("IdGroupApp", "DateFrom", "DateTo", "IdStatus", "IdEmployeer") FROM stdin;
\.


--
-- Data for Name: GroupApplicationVisitor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupApplicationVisitor" ("IdGroupAppVisitor", "IdGroupApp", "IdVisitor") FROM stdin;
\.


--
-- Data for Name: PersonalApplication; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PersonalApplication" ("IdPersApp", "DateFrom", "DateTo", "IdVisitor", "IdStatus", "IdEmployeer") FROM stdin;
\.


--
-- Data for Name: RequireDocument; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RequireDocument" ("IdDoc", "DocLink") FROM stdin;
\.


--
-- Data for Name: Status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Status" ("IdStatus", "StatusName") FROM stdin;
1	Проверка
2	Одобрено
3	Не одобрено
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" ("IdUser", "Email", "Password", "Login") FROM stdin;
1	Radinka100@yandex.ru	b3uWS6#Thuvq	Vlas86
2	Prohor156@list.ru	zDdom}SIhWs?	Prohor156
3	YUrin155@gmail.com	u@m*~ACBCqNQ	YUrin155
4	Aljbina33@lenta.ru	Bu?BHCtwDFin	Aljbina33
5	Klavdiya113@live.com	FjC#hNIJori}	Klavdiya113
6	Tamara179@live.com	TJxVqMXrbesI	Tamara179
7	Taras24@rambler.ru	07m5yspn3K~K	Taras24
8	Arkadij123@inbox.ru	vk2N7lxX}ck%	Arkadij123
9	Glafira73@outlook.com	Zz8POQlP}M4~	Glafira73
10	Gavriila68@msn.com	x4K5WthEe8ua	Gavriila68
11	Kuzjma124@yandex.ru	OsByQJ}vYznW	Kuzjma124
12	Roman89@gmail.com	Xd?xP$2yICcG	Roman89
13	Aleksej43@gmail.com	~c%PlTY0?qgl	Aleksej43
14	Nadezhda137@outlook.com	QQ~0q~rXHb?p	Nadezhda137
15	Bronislava56@yahoo.com	LO}xyC~1S4l6	Bronislava56
\.


--
-- Data for Name: Visitor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Visitor" ("IdVisitor", "Name", "Surname", "Patronymic", "Phone", "Organization", description, "DateOfBirth", "PassportSerial", "PassportNumber", iddoc, "IdUser", "ImagePath") FROM stdin;
\.


--
-- Name: Department Department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_pkey" PRIMARY KEY ("IdDep");


--
-- Name: Employeer Employeer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employeer"
    ADD CONSTRAINT "Employeer_pkey" PRIMARY KEY ("IdEmployeer");


--
-- Name: GroupApplicationVisitor GroupApplicationVisitor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplicationVisitor"
    ADD CONSTRAINT "GroupApplicationVisitor_pkey" PRIMARY KEY ("IdGroupAppVisitor");


--
-- Name: GroupApplication GroupApplication_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_pkey" PRIMARY KEY ("IdGroupApp");


--
-- Name: PersonalApplication PersonalApplication_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonalApplication"
    ADD CONSTRAINT "PersonalApplication_pkey" PRIMARY KEY ("IdPersApp");


--
-- Name: RequireDocument RequireDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequireDocument"
    ADD CONSTRAINT "RequireDocument_pkey" PRIMARY KEY ("IdDoc");


--
-- Name: Status Status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Status"
    ADD CONSTRAINT "Status_pkey" PRIMARY KEY ("IdStatus");


--
-- Name: User User_Email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_Email_key" UNIQUE ("Email");


--
-- Name: User User_Login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_Login_key" UNIQUE ("Login");


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY ("IdUser");


--
-- Name: Visitor Visitor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visitor"
    ADD CONSTRAINT "Visitor_pkey" PRIMARY KEY ("IdVisitor");


--
-- Name: Employeer Employeer_IdDep_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employeer"
    ADD CONSTRAINT "Employeer_IdDep_fkey" FOREIGN KEY ("IdDep") REFERENCES public."Department"("IdDep");


--
-- Name: GroupApplicationVisitor GroupApplicationVisitor_IdGroupApp_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplicationVisitor"
    ADD CONSTRAINT "GroupApplicationVisitor_IdGroupApp_fkey" FOREIGN KEY ("IdGroupApp") REFERENCES public."GroupApplication"("IdGroupApp");


--
-- Name: GroupApplicationVisitor GroupApplicationVisitor_IdVisitor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplicationVisitor"
    ADD CONSTRAINT "GroupApplicationVisitor_IdVisitor_fkey" FOREIGN KEY ("IdVisitor") REFERENCES public."Visitor"("IdVisitor");


--
-- Name: GroupApplication GroupApplication_IdEmployeer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_IdEmployeer_fkey" FOREIGN KEY ("IdEmployeer") REFERENCES public."Employeer"("IdEmployeer");


--
-- Name: GroupApplication GroupApplication_IdStatus_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_IdStatus_fkey" FOREIGN KEY ("IdStatus") REFERENCES public."Status"("IdStatus");


--
-- Name: PersonalApplication PersonalApplication_IdEmployeer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonalApplication"
    ADD CONSTRAINT "PersonalApplication_IdEmployeer_fkey" FOREIGN KEY ("IdEmployeer") REFERENCES public."Employeer"("IdEmployeer");


--
-- Name: PersonalApplication PersonalApplication_IdStatus_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonalApplication"
    ADD CONSTRAINT "PersonalApplication_IdStatus_fkey" FOREIGN KEY ("IdStatus") REFERENCES public."Status"("IdStatus");


--
-- Name: PersonalApplication PersonalApplication_IdVisitor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonalApplication"
    ADD CONSTRAINT "PersonalApplication_IdVisitor_fkey" FOREIGN KEY ("IdVisitor") REFERENCES public."Visitor"("IdVisitor");


--
-- Name: Visitor Visitor_IdUser_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visitor"
    ADD CONSTRAINT "Visitor_IdUser_fkey" FOREIGN KEY ("IdUser") REFERENCES public."User"("IdUser");


--
-- Name: Visitor Visitor_iddoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visitor"
    ADD CONSTRAINT "Visitor_iddoc_fkey" FOREIGN KEY (iddoc) REFERENCES public."RequireDocument"("IdDoc");


--
-- PostgreSQL database dump complete
--

