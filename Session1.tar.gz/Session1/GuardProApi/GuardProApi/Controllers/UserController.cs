using GuardProApi.DataContext;
using GuardProApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace GuardProApi.Controllers;


[Route("Api/[controller]")]
[Controller]
public class UserController : Controller
{
    [HttpGet]
    [Route("GetAllUsers")]
    public IEnumerable<User> GetAllUsers()
    {
        List<User> data = new List<User>();
        using (Entity db = new Entity())
        {
            var list = db.User.ToList();
            data = list;

        }

        return Enumerable.Range(0, data.Count).Select(x => data[x]);
    }

    [HttpGet]
    [Route("GetUser")]
    public IEnumerable<User> GetUser(int id)
    {
        User u = new User();
        using (Entity db = new Entity())
        {
            var user = db.User.ToList().Where(i => i.IdUser == id).FirstOrDefault();
            u = user;
        }

        return Enumerable.Range(0, 1).Select(x => u);
    }
}        