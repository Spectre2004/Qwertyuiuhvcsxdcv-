namespace GuardProApi.DataContext;
using GuardProApi.Models;
using Microsoft.EntityFrameworkCore;

public class Entity : DbContext
{
    public DbSet<User> User { get; set; }
    public Entity()
    {
        Database.EnsureCreated();
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        optionsBuilder.UseNpgsql("Host=10.54.6.14; Port=5432; Database=GuardPRO; Username=postgres; Password=1231234");
    }
}